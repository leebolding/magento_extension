<?php
class TVPage_Connect_Block_Output extends Mage_Core_Block_Template {
	protected function _toHtml() {
		return 'Welldone';
	}
}
?>